﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Xml;
using System.IO;
using Microsoft.Xrm.Sdk.Messages;


namespace Savants
{

   public class GetBase64Image : CodeActivity
    {
       [Input("Image Webresource")]
       [RequiredArgument]
       [ReferenceTarget("webresource")]
       public InArgument<EntityReference> Webresource { get; set; }

       [Output("imageHtml")]
       [RequiredArgument]
       public OutArgument<string> imageHtml { get; set; }
       protected override void Execute(CodeActivityContext executionContext)
       {
           ITracingService traceservice = executionContext.GetExtension<ITracingService>();


           try
           {
               traceservice.Trace("Workflow started");
               IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
               IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
               IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

               if (Webresource.Get(executionContext) != null )
               {
                   Entity image = service.Retrieve("webresource", Webresource.Get(executionContext).Id, new ColumnSet("content", "displayname"));
                   imageHtml.Set(executionContext, "<img alt='" + image["displayname"] + "' src='data:image/png;base64," + image["content"] + "' />");
               }
              
           }
           catch (Exception ex)
           {
               traceservice.Trace("Error occured: " + ex.ToString());
               throw new InvalidPluginExecutionException(ex.ToString());

           }


       }
    }
}
