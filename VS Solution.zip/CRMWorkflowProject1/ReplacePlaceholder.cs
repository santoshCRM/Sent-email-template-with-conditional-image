﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace Savants
{
    public class ReplacePlaceholder : CodeActivity
    {
        #region Workflow Arguments
        [Input("PlaceHolder")]
        [RequiredArgument]
        public InArgument<string> PlaceHolder { get; set; }

        [Input("ImageHTML")]
        [RequiredArgument]
        public InArgument<string> ImageHTML { get; set; }

        [Input("Email")]
        [RequiredArgument]
        [ReferenceTarget("email")]
        public InArgument<EntityReference> EmailSource { get; set; }
        #endregion
        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService traceService = executionContext.GetExtension<ITracingService>();
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            traceService.Trace("Workflow Started");
            try
            {
                Entity email = service.Retrieve(EmailSource.Get(executionContext).LogicalName, EmailSource.Get(executionContext).Id, new ColumnSet("description"));
                email.Attributes["description"] = email.Attributes["description"].ToString().Replace(PlaceHolder.Get(executionContext),
                    ImageHTML.Get(executionContext));
                service.Update(email);
                
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException("Error occured !!" + ex.Message.ToString());
            }
        }

     

    }
}
