﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace Savants
{
    public class UpdateEmailFromEmailTemplate : CodeActivity
    {
        #region Workflow Arguments
        [Input("Email Source")]
        [RequiredArgument]
        [ReferenceTarget("email")]
        public InArgument<EntityReference> EmailSource { get; set; }

        [Input("Email Template")]
        [RequiredArgument]
        [ReferenceTarget("template")]
        public InArgument<EntityReference> EmailTemplate { get; set; }
        [Input("Case")]
        [RequiredArgument]
        [ReferenceTarget("incident")]
        public InArgument<EntityReference> Case { get; set; }
        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService traceService = executionContext.GetExtension<ITracingService>();
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            traceService.Trace("Workflow Started");
            try
            {
              //  Entity emailT = service.Retrieve(EmailTemplate.Get(executionContext).LogicalName, EmailTemplate.Get(executionContext).Id, new ColumnSet("body", "subject"));
                InstantiateTemplateRequest instTemplateReq = new InstantiateTemplateRequest
                {
                    //TemplateId = new Guid("dfd4fdf0-902e-450b-a4d6-71feb7bd0b41"),
                    //ObjectId = new Guid("0A9F62A8-90DF-E311-9565-A45D36FC5FE8"),
                    //ObjectType = "incident"
                    TemplateId = EmailTemplate.Get(executionContext).Id,
                    ObjectId = Case.Get(executionContext).Id,
                    ObjectType = Case.Get(executionContext).LogicalName
                };
                InstantiateTemplateResponse instTemplateResp = (InstantiateTemplateResponse)service.Execute(instTemplateReq);
                if (instTemplateResp.EntityCollection.Entities.Count > 0)
                {
                    traceService.Trace("Workflow Started 1");
                    traceService.Trace("Workflow Started 1 " + instTemplateResp.EntityCollection.Entities.Count().ToString());
                    Entity emailT = (Entity)instTemplateResp.EntityCollection.Entities[0];
                    traceService.Trace("Workflow Started 3");
                    Entity email = service.Retrieve(EmailSource.Get(executionContext).LogicalName, EmailSource.Get(executionContext).Id, new ColumnSet("description", "subject"));
                    traceService.Trace("Workflow Started 4 1");
                    email.Attributes["description"] = emailT.Attributes.Contains("description") ? (String)emailT.Attributes["description"] : "";
                    traceService.Trace("Workflow Started 5");
                    email.Attributes["subject"] = emailT.Attributes.Contains("subject") ? (String)emailT.Attributes["subject"] : "";
                    traceService.Trace("Workflow Started 6");
                    service.Update(email);
                }
                else
                {
                    traceService.Trace("Template not found");
                    throw new InvalidPluginExecutionException("Template not found");
                }

            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException("Error occured !!" + ex.Message.ToString());
            }
        }
        private static string GetDataFromXml(string value, string attributeName)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }
            XDocument document = XDocument.Parse(value);
            // get the Element with the attribute name specified 
            XElement element = document.Descendants().Where(ele => ele.Attributes().Any(attr => attr.Name == attributeName)).FirstOrDefault();
            return element == null ? string.Empty : element.Value;
        }
    }
}
