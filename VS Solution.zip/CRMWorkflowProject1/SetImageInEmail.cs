﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace Savants
{
     class SetImageInEmail : CodeActivity
    {
        #region Workflow Arguments
        [Input("PlaceHolder")]
        [RequiredArgument]
        public InArgument<string> PlaceHolder { get; set; }

        [Input("ImageHTML")]
        [RequiredArgument]
        public InArgument<string> ImageHTML { get; set; }

        [Input("Email Template")]
        [RequiredArgument]
        [ReferenceTarget("template")]
        public InArgument<EntityReference> EmailTemplate { get; set; }
        [Input("Case")]
        [RequiredArgument]
        [ReferenceTarget("incident")]
        public InArgument<EntityReference> Case { get; set; }

        #endregion
        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService traceService = executionContext.GetExtension<ITracingService>();
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            traceService.Trace("Workflow Started");
            try
            {
                Entity emailT = service.Retrieve(EmailTemplate.Get(executionContext).LogicalName, EmailTemplate.Get(executionContext).Id, new ColumnSet("body"));
                Entity caseEntity = service.Retrieve(Case.Get(executionContext).LogicalName, Case.Get(executionContext).Id, new ColumnSet("customerid"));
                SendMail(service, ImageHTML.Get(executionContext), PlaceHolder.Get(executionContext), emailT, caseEntity, context.UserId);

                //SendEmailRequest sendEmailreq = new SendEmailRequest
                //{
                //    EmailId = Email.Get(executionContext).Id,
                //    TrackingToken = "",
                //    IssueSend = true
                //};

                //SendEmailResponse sendEmailresp = (SendEmailResponse)service.Execute(sendEmailreq);

            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException("Error occured !!" + ex.Message.ToString());
            }
        }

        private void SendMail(IOrganizationService service, string ImageHTML, string PlaceHolder, Entity emailT, Entity caseEntity, Guid _userId)
        {

            Entity email = new Entity();
            email.LogicalName = "email";
            email.Attributes["description"] = GetDataFromXml(emailT.Attributes["body"].ToString(), "match");
            string urlToReplace = ImageHTML;
            email.Attributes["description"] = email.Attributes["description"].ToString().Replace(PlaceHolder, urlToReplace);
            Entity fromParty =new Entity("activityparty");
            fromParty.Attributes["partyid"] = new EntityReference("systemuser", _userId);
            Entity toParty =new Entity("activityparty");
            EntityReference customer=(EntityReference) caseEntity.Attributes["customerid"];
            fromParty.Attributes["partyid"] = new EntityReference(customer.LogicalName,customer.Id);
            email.Attributes["to"] = toParty;
            email.Attributes["from"] = fromParty;
          //  service.Create(email);
            //InstantiateTemplateRequest instTemplateReq = new InstantiateTemplateRequest
            //{
            //    TemplateId = emailT.Id,
            //    ObjectId = caseEntity.Id,
            //    ObjectType = caseEntity.LogicalName
            //};
            //InstantiateTemplateResponse instTemplateResp = (InstantiateTemplateResponse)service.Execute(instTemplateReq);

            //XmlSerializer serializer = new XmlSerializer(typeof(InstantiateTemplateResponse));
            //using (StringWriter writer = new StringWriter())
            //{
            //    serializer.Serialize(writer, instTemplateResp);
            //    string filename = writer.ToString();
            //}
            //SendEmailFromTemplateRequest emailUsingTemplateReq = new SendEmailFromTemplateRequest
            //{
            //    Target = email,
            //    TemplateId = emailT.Id,
            //    // The regarding Id is required, and must be of the same type as the Email Template.
            //    RegardingId = caseEntity.Id,
            //    RegardingType = caseEntity.LogicalName
            //};
            //SendEmailFromTemplateResponse emailUsingTemplateResp = (SendEmailFromTemplateResponse)service.Execute(emailUsingTemplateReq);
        }

        private static string GetDataFromXml(string value, string attributeName)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }
            XDocument document = XDocument.Parse(value);
            // get the Element with the attribute name specified 
            XElement element = document.Descendants().Where(ele => ele.Attributes().Any(attr => attr.Name == attributeName)).FirstOrDefault();
            return element == null ? string.Empty : element.Value;
        }

    }
}
